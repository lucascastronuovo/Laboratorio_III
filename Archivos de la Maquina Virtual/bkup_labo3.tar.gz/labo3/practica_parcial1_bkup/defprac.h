#ifndef _DEFI_H
#define _DEFI_H


#define VERDE 1
#define LARGO 51

#endif
