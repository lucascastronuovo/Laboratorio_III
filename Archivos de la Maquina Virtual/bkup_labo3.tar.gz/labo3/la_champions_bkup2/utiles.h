#ifndef UTILES_H
#define UTILES_H

#define POS 0
#define LINEAS_PANTALLA 100




void limpiarPantalla();

void configurarMemoriaInicial(int* inicializado);

void verificarMemoriaInicial(int* inicializado);



#endif
