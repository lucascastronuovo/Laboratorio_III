#ifndef _EVENTOS_H
#define _EVENTOS_H


void procesarEvento(int id_cola_mensajes, int opc_pateador, int nro_jugador);

#endif
