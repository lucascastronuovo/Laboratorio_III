#include <stdio.h>
#include <stdlib.h>




int main(int argc, char *argv[]){

	int id_cola_mensajes;

	return 0;

}
