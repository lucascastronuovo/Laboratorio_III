#include <pthread.h>
#include "global.h"



Destinos destinos;

Eventos eventos;

pthread_mutex_t mutex;

int* inicializado;
