#include <stdio.h>
#include "gestiones.h"

int producir(FILE *pro,int n,char *nompro){
	
	

	
	
		

		fprintf(pro,"%s-%02d\n",nompro,n);		


	return 0;
}

int consumir(FILE *con){

	char nomcon[20];
		
	
		
		while(!feof(con)){
			
			fscanf(con,"%s\n",nomcon);
			printf("Se consumió: %s\n",nomcon);
			

		}
		
	

	return 0;
}
