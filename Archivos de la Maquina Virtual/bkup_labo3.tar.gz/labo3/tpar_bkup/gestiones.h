#ifndef _GESTIONES_H
#define _GESTIONES_H


int producir(FILE *pro, int n,char *nompro);

int consumir(FILE *con);


#endif
