#ifndef _DEFI_H
#define _DEFI_H

#define DESDE 0
#define HASTA 10
#define CANTIDAD 10
#define TRUE 1
#define FALSE 0

#endif
