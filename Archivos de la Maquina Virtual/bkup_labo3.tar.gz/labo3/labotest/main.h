#ifndef _main
#define _main
#include "stdio.h"
#include "stdlib.h"

#define valort "prueba"

typedef struct casa casita;

struct casa
{
	int patio;
};

typedef struct casauna
{
	int patio;
}CASAuNA;

#endif

