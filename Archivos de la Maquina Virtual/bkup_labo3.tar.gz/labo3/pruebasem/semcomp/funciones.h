#ifndef _FUNCIONES_H
#define _FUNCIONES_H

int obtenerAleatorio();
void obtenerArrayAleatorio(int *arr, int size);

#endif
