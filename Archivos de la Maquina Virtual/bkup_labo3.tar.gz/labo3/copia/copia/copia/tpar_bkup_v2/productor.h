#ifndef _PRODUCTOR_H
#define _PRODUCTOR_H


void producir();

#endif
