#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "menu_archivos.h"

int main(int argc, char *argv[]){
	
	
	if(argc == 1){
		
		abrirMenu();

	}
	else{
		
		printf("Error: Se han ingresados parámetros\n");
	
	}
	
	
	
	
	return 0;


}
