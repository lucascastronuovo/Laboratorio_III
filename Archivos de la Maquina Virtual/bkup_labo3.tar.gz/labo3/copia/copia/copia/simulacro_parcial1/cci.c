#include <stdio.h>
#include <stdlib.h>
#include "menucci.h"


int main(int argc, char *argv[]){
	
	abrirMenuCCI();


	return 0;

}
