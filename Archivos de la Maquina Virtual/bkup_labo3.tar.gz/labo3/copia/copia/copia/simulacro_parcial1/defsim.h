#ifndef _DEFI_H
#define _DEFI_H

#define ROJO 0
#define VERDE 1
#define CLAVE_BASE 33
#define LARGO_MENSAJE 20+1
#define INTERVALO_CHEQUEO 100000


#endif
