#include <stdio.h>

int main(int incant, char *szarg[]) {
	
	printf("Hola Mundo\n");
	return 0;

}
