#ifndef _DEFI_H
#define _DEFI_H

#define ROJO 0
#define VERDE 1
#define CLAVE_BASE 33
#define CAPACIDAD 20
#define NOMARCH "lote.dat"
#define NU_NOMARCH "lote.%03d.dat"

#endif
