#ifndef _SEMAFOROS_H
#define _SEMAFOROS_H

int creo_semaforo(int);
void inicia_semaforo(int, int);
void levanta_semaforo(int);
void espera_semaforo(int);

#endif
