#ifndef _FUNCIONES_H
#define _FUNCIONES_H


int obtenerNumeroAleatorio(int desde, int hasta);

#endif
