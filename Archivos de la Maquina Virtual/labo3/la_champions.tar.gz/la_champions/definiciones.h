#ifndef _DEFI_H
#define _DEFI_H

#define LARGO 50
#define ROJO 0
#define VERDE 1
#define CLAVE_BASE 33
#define CANT_PATEADORES 2
#define NRO_JULIAN 19
#define NRO_LAUTARO 10



#endif
