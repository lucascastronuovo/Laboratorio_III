#ifndef _DEFI_H
#define _DEFI_H


#define CLAVE_BASE 33
#define CANT_JUGADORES 2




#endif
