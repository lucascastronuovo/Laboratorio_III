#ifndef _FUNCOLAS_H
#define _FUNCOLAS_H

void procesar_evento_mac(int id_cola_mensajes);

void procesar_evento_cons(int id_cola_mensajes);

#endif
