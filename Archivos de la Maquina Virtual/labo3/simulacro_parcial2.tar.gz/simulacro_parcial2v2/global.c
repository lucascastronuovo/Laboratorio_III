#include <pthread.h>
#include "global.h"


jugador *datos_threads=0;

Destinos destinos;

Eventos eventos;

pthread_mutex_t mutex;

inicializado *memoria;
