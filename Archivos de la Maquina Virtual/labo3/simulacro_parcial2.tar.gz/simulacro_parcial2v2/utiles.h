#ifndef UTILES_H
#define UTILES_H

#define POS 0
#define LINEAS_PANTALLA 100




void limpiarPantalla();

void configurarMemoriaInicial(int* ini);

void verificarMemoriaInicial(int* ini);



#endif
