#include <stdio.h>
#include <stdlib.h>
#include "funciones.h"

int obtenerNumeroAleatorio(int desde, int hasta){

	
	return (rand()%(hasta-desde+1))+desde;
	

}





