#ifndef _THREADS_H
#define _THREADS_H


void *threadJugador(void *parametro);

#endif
