#ifndef _THREADS_H
#define _THREADS_H


void *funcionThread(void *parametro);

#endif
