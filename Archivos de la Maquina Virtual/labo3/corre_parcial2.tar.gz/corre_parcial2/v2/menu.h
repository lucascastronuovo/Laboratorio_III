#ifndef _MENU_H
#define _MENU_H

int menu(int cant, int *n_hormiga);

#endif
