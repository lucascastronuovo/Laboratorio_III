#ifndef _THREADS_H
#define _THREADS_H


void *threadHormiga(void *parametro);

#endif
