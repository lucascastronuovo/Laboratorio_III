#ifndef _DEF_GEN_H
#define _DEF_GEN_H

#define ROJO 0
#define VERDE 1
#define LARGO 51

#endif
