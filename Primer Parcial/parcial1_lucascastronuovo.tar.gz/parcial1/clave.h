#ifndef _CLAVE_H
#define _CLAVE_H


key_t creo_clave(int r_clave);

#endif
